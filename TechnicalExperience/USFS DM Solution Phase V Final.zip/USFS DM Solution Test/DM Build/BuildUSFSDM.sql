--USFS2021 developed and writted by Keanan Anderson
--Written for INFO 3300
--Originally Created: October 2021
--Updated: October 2021
-----------------------
-----------------------
IF NOT EXISTS(SELECT * FROM sys.databases
	WHERE NAME = N'USFSDM')
	CREATE DATABASE USFSDM
GO 
-- 
USE USFSDM
GO
--
--Drop Existing Tables
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'FactAssignment'
	)
	DROP TABLE FactAssignment;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'DimForest'
	)
	DROP TABLE DimForest;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'DimProject'
	)
	DROP TABLE DimProject;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'DimEmployee'
	)
	DROP TABLE DimEmployee;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'DimDate'
	)
	DROP TABLE DimDate;
--
--Create New Tables
CREATE TABLE DimEmployee (
	Employee_SK			INT IDENTITY (1,1) NOT NULL CONSTRAINT pk_employee_sk PRIMARY KEY,
	Employee_AK			INT NOT NULL,
	DOB					DATE NOT NULL,
	Hire_Date			DATE NOT NULL,
	Leave_Date			DATE,
	Employee_Level		NVARCHAR(4) NOT NULL, --Identifies experience level of Employee
	Heavy_Machinery		BIT,
	First_Name			NVARCHAR(50) NOT NULL,
	Last_Name			NVARCHAR(50) NOT NULL,
	Department_Type		NVARCHAR(30) NOT NULL, --Identifies what department the Employee works for
	District_Name		NVARCHAR(50) NOT NULL, --Identifies what district the Employee works for
	Phone				NVARCHAR(14) NOT NULL
	);
CREATE TABLE DimProject(
	Project_SK			INT IDENTITY (1,1) NOT NULL CONSTRAINT pk_project_sk PRIMARY KEY,
	Project_AK			INT NOT NULL,
	Location			NVARCHAR(40) NOT NULL,
	Trail_Work			BIT,
	Trail_Name			NVARCHAR(40),
	Project_Type		NVARCHAR(6) NOT NULL, --How difficult the project is
	Project_Scope		NVARCHAR(6) NOT NULL, --How large the project is
	Heavy_Machinery		BIT,
	Longitude			DECIMAL (9,4) NOT NULL,
	Latitude			DECIMAL (9,4) NOT NULL
);
--
CREATE TABLE DimForest(
	Forest_SK			INT IDENTITY (1,1) NOT NULL CONSTRAINT pk_forest_sk PRIMARY KEY,
	Forest_AK			INT NOT NULL,
	Forest_Name			NVARCHAR(25) NOT NULL,
	Size				INT NOT NULL,
	State				NVARCHAR(4),
	Longitude			DECIMAL (9,4) NOT NULL, --Initial Location of Forest
	Latitude 			DECIMAL (9,4) NOT NULL --Initial Location of Forest
);
--
CREATE TABLE DimDate 
	(Date_SK			INT CONSTRAINT pk_date_sk PRIMARY KEY, 
	Date				DATE,
	FullDate			NCHAR(10),-- Date in MM-dd-yyyy format
	DayOfMonth			INT, -- Field will hold day number of Month
	DayName				NVARCHAR(9), -- Contains name of the day, Sunday, Monday 
	DayOfWeek			INT,-- First Day Sunday=1 and Saturday=7
	DayOfWeekInMonth	INT, -- 1st Monday or 2nd Monday in Month
	DayOfWeekInYear		INT,
	DayOfQuarter		INT,
	DayOfYear			INT,
	WeekOfMonth			INT,-- Week Number of Month 
	WeekOfQuarter		INT, -- Week Number of the Quarter
	WeekOfYear			INT,-- Week Number of the Year
	Month				INT, -- Number of the Month 1 to 12{}
	MonthName			NVARCHAR(9),-- January, February etc
	MonthOfQuarter		INT,-- Month Number belongs to Quarter
	Quarter				NCHAR(2),
	QuarterName			NVARCHAR(9),-- First,Second..
	Year				INT,-- Year value of Date stored in Row
	YearName			CHAR(7), -- CY 2017,CY 2018
	MonthYear			CHAR(10), -- Jan-2018,Feb-2018
	MMYYYY				INT,
	FirstDayOfMonth		DATE,
	LastDayOfMonth		DATE,
	FirstDayOfQuarter	DATE,
	LastDayOfQuarter	DATE,
	FirstDayOfYear		DATE,
	LastDayOfYear		DATE,
	IsHoliday			BIT,-- Flag 1=National Holiday, 0-No National Holiday
	IsWeekday			BIT,-- 0=Week End ,1=Week Day
	Holiday				NVARCHAR(50),--Name of Holiday in US
	Season				NVARCHAR(10)--Name of Season
	);
--
CREATE TABLE FactAssignment(
	Assignment_ID_DD	INT NOT NULL,
	Employee_SK 		INT NOT NULL, 
	Project_SK 			INT NOT NULL, --separate from Fact table Project
	Forest_SK 			INT NOT NULL,
	Project_Count		INT,
	Crew_Size			INT, --How many members are on each project
	Start_Date			INT NOT NULL,
	End_Date			INT NOT NULL,
	Project_Length		INT,
	CONSTRAINT pk_fact_assignment PRIMARY KEY (Assignment_ID_DD, Employee_SK, Project_SK, Forest_SK),
	CONSTRAINT fk_begin_dim_date FOREIGN KEY (Start_Date) REFERENCES DimDate(Date_SK),
	CONSTRAINT fk_end_dim_date FOREIGN KEY (End_Date) REFERENCES DimDate(Date_SK),
	CONSTRAINT fk_dim_employee FOREIGN KEY (Employee_SK) REFERENCES DimEmployee (Employee_SK),
	CONSTRAINT fk_dim_project FOREIGN KEY (Project_SK) REFERENCES DimProject (Project_SK),
	CONSTRAINT fk_dim_forest FOREIGN KEY (Forest_SK) REFERENCES DimForest (Forest_SK)
);
