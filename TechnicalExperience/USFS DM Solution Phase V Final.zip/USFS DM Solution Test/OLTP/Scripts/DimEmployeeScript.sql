-- Script written by Keanan Anderson
-- Originally written: October 2021
-- Query to fill & connect DimEmployee Table
SELECT 	Employee.EmployeeID, 
		Employee.EmpDOB AS DOB, 
		EmployeeHistory.EmpStartDate AS Hire_Date, 
		EmployeeHistory.EmpEndDate AS Leave_Date, 
		EmployeeType.EmpLevel AS Employee_Level, 
        EmployeeType.EmpHeavyMachinery AS Heavy_Machinery, 
        DepartmentType.DepartmentType AS Department_Type, 
        District.DistrictName AS District_Name, 
        Employee.EmpPhone AS Phone
FROM    Employee INNER JOIN EmployeeHistory 
        	ON Employee.EmployeeID = EmployeeHistory.EmployeeID 
        INNER JOIN Department 
        	ON EmployeeHistory.DepartmentID = Department.DepartmentID 
        INNER JOIN DepartmentType 
        	ON Department.DepartmentTypeID = DepartmentType.DepartmentTypeID 
        INNER JOIN District 
        	ON Department.DistrictID = District.DistrictID 
       	INNER JOIN EmployeeType 
       		ON Employee.EmployeeTypeID = EmployeeType.EmployeeTypeID