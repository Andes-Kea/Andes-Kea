-- Script written by Keanan Anderson
-- Originally written: October 2021
-- Query to Select Given Attributes to the FactAssignment Table
SELECT
	USFS.dbo.Assignment.AssignmentID AS Assignment_ID_DD,
	DimEmployee.Employee_SK,
	DimProject.Project_SK,
	DimForest.Forest_SK,
	Project_Count = Count(Assignment.AssignedProjectID),
	Crew_Size = Count(Assignment.AssignedEmployeeID),
	DT1.Date_SK AS Start_Date,
	DT2.Date_SK AS End_Date,
	Project_Length = (DT2.Date_SK - DT1.Date_SK)
FROM USFS.dbo.Assignment
INNER JOIN USFS.dbo.Employee
	ON USFS.dbo.Assignment.AssignedEmployeeID = USFS.dbo.Employee.EmployeeID
INNER JOIN USFS.dbo.EmployeeHistory
	ON USFS.dbo.Employee.EmployeeID = USFS.dbo.EmployeeHistory.EmployeeID
INNER JOIN USFS.dbo.Department
	ON USFS.dbo.EmployeeHistory.DepartmentID = USFS.dbo.Department.DepartmentID
INNER JOIN USFS.dbo.District
	ON USFS.dbo.Department.DistrictID = USFS.dbo.District.DistrictID
INNER JOIN USFS.dbo.NTLForest
	ON USFS.dbo.District.NTLForestID = USFS.dbo.NTLForest.ForestID
INNER JOIN USFS.dbo.Project
	ON USFS.dbo.Assignment.AssignedProjectID = USFS.dbo.Project.ProjectID
INNER JOIN DimEmployee
	ON DimEmployee.Employee_AK = USFS.dbo.Assignment.AssignedEmployeeID
INNER JOIN DimProject
	ON DimProject.Project_AK = USFS.dbo.Assignment.AssignedProjectID
INNER JOIN DimForest
	ON DimForest.Forest_AK = USFS.dbo.NTLForest.ForestID
INNER JOIN DimDate AS DT1
	ON DT1.Date = USFS.dbo.Assignment.AssignmentStartDate
INNER JOIN DimDate AS DT2
	ON DT2.Date = USFS.dbo.Assignment.AssignmentEndDate
GROUP BY
	Assignment.AssignmentID,
	DimEmployee.Employee_SK,
	DimProject.Project_SK,
	DimForest.Forest_SK,
	DT1.Date_SK,
	DT2.Date_SK