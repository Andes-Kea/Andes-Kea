-- Script written by Keanan Anderson
-- Originally written: October 2021
-- Query for DimProject Table
SELECT 	Project.ProjectID, 
		Project.ProLocation AS Location, 
		Project.ProTrailWork AS Trail_Work, 
		ISNULL(Project.ProTrailName, 'N/A') AS Trail_Name, 
		Project.ProLongitude AS Longitude, 
		Project.ProLatitude AS Latitude, 
		ProjectType.ProjectType AS Project_Type, 
		ProjectType.ProjectScope AS Project_Scope, 
        ProjectType.HeavyEquipment AS Heavy_Equipment
FROM	Project 
	LEFT OUTER JOIN ProjectType 
		ON Project.ProjectTypeID = ProjectType.ProjectTypeID