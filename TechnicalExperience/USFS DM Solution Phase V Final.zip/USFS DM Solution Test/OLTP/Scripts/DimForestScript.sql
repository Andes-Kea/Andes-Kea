-- Script written by Keanan Anderson
-- Originally written: October 2021
-- Query fill & connect DimForest Table
SELECT 	ForestID, 
		ForestName AS Forest_Name, 
		ForestSize AS Size, 
		ForestState AS State, 
		ForestLongitude AS Longitude, 
		ForestLatitude AS Latitude
FROM    NTLForest